
import java.util.Scanner;

public class GradeCalculaterMain{
    public static void main(String[] args){
   
     
 Scanner scnr = new Scanner(System.in);
 GradeCalculater student1 = new GradeCalculater();
      // set up the variables we will use to get user input.
      double projectScoreAvg = 0.0;
      double labScoreAvg = 0.0;
      double zybooksScoreAvg = 0.0;
      double totalOfAllScores;
      double examAvg = 0.0;
      double examTotalScore;
      int numOfExams;
      double examValue;
      double totalAvgGrade;
      double examWeight;
      double projectWeight;
      double zybooksWeight;
      double labWeight;
      char letterGrade;
      double projectScoreAvgW = 0;
      double labScoreAvgW = 0;
      double zybooksScoreAvgW = 0;
      double examAvgW = 0;
      
      
      
      System.out.println("Welcome to the Grade Calculater");
      System.out.println("To start your grade calculation enter your avg Project Score");
      student1.setAvgProjScore(scnr.nextDouble());
      projectScoreAvg = student1.getAvgProjScore();
      System.out.println("Enter your avg Zybooks Score");        /*sets and gets methods are used to assign variable values*/
       student1.setAvgZybooksScore(scnr.nextDouble());
      zybooksScoreAvg = student1.getAvgZybooksScore();     
      System.out.println("Enter your avg lab Score");
      student1.setAvgLabScore(scnr.nextDouble());
      labScoreAvg = student1.getAvgLabScore();    
      System.out.println("Enter the number of exam Scores you have");
      numOfExams = scnr.nextInt();
      
      double[] examScores = new double[numOfExams];   /*gives each array variable a value in the array*/
      for(int i=0;i<numOfExams;++i){
      System.out.println("Enter a exam Value");
      examValue = scnr.nextDouble();
      examScores[i]= examValue;
      }
      
      
      examTotalScore = 0;
      for(int i=0;i<numOfExams;++i){         /*calculates avg exam score using array values*/
      examTotalScore = examScores[i] + examTotalScore;
      }
      student1.setAvgExamScore(examTotalScore,numOfExams);
      System.out.println("Your Avg Exam Score is " + student1.getAvgExamScore());   /*Avg exam methods are used to calculate avg score*/
      examAvg=student1.getAvgExamScore();
      
      if(examAvg > 50){
      System.out.println("Exam avg is Greater than 50!");
      }                                                          /*outputs if exam avg is greater than 50*/
      else{
      System.out.println("Exam avg is less than 50!");
      }
      
      System.out.println("To calculate numerical grade avg enter the following weights");
      System.out.println("Project Weight");
      projectWeight = scnr.nextDouble();
      System.out.println("Zybooks Weight");        /*sets averages equal to their value*/
      zybooksWeight = scnr.nextDouble();
      System.out.println("Labs Weight");
      labWeight = scnr.nextDouble();
      System.out.println("Exam Weight");
      examWeight = scnr.nextDouble(); 
      
      double totalWeight = examWeight +labWeight + zybooksWeight + projectWeight;
      if(totalWeight == 1.0){
      projectScoreAvgW = projectScoreAvg * projectWeight;         /*sets weighted avgs equal to its variable*/
      labScoreAvgW = labScoreAvg * labWeight;
      zybooksScoreAvgW = zybooksScoreAvg * zybooksWeight;
      examAvgW = examAvg * examWeight;
      }
      else{
         System.out.println("Weight doesnt equal 1.0, Stop program, and retype data");
        totalWeight= -1;
         }
         
       totalAvgGrade = projectScoreAvgW + labScoreAvgW + zybooksScoreAvgW + examAvgW;                      
      if(totalAvgGrade <=100 && totalAvgGrade>=90){
      letterGrade = 'A';
      }
      else if(totalAvgGrade <90 && totalAvgGrade>=80 ){           /*assigns a letter grade to the avg*/
      letterGrade = 'B';
      }
      else if(totalAvgGrade <80 && totalAvgGrade>=70 ){
      letterGrade = 'C';
      }
      else if(totalAvgGrade <70 && totalAvgGrade>=60 ){
      letterGrade = 'D';
      }
      else{
      letterGrade = 'F';
      }
      
      System.out.println("Project Avg is " + projectScoreAvg);
      System.out.println("Lab Avg is " + labScoreAvg);                     /*states all data*/
      System.out.println("Zybooks Avg is " + zybooksScoreAvg);
      System.out.println("Exam Avg is " + examAvg);
      System.out.println(" Weight total is " + totalWeight);
      System.out.println(" If weight total is equal to -1. Weights were entered incorrectly");
      System.out.println("Total Avg is " + totalAvgGrade);
      System.out.println("Final Letter Grade " + letterGrade);

     


      
       


      
      
      
      
   }
 }      