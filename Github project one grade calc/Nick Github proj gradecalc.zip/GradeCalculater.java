public class GradeCalculater{

/*instance variable Delclarations*/
   private double projectScoreAvg;
   private double labScoreAvg;
   private double zybooksScoreAvg;
   private double examScoreAvg;
   private double totalOfAllScores;
   private double avgNumGrade;
   
   /*instance variable*/
public GradeCalculater(){
 projectScoreAvg = 0.0;
 labScoreAvg = 0.0;
 zybooksScoreAvg = 0.0;
 examScoreAvg = 0.0;
}
   
/*calculates Average for projects*/
public void setAvgProjScore(double avgScoreOfProj){
    this.projectScoreAvg = avgScoreOfProj;
 }
 
 /*returns Average for projects*/
public double getAvgProjScore(){
   return projectScoreAvg;
   }
   
   /*calculates Average for exams*/
public void setAvgExamScore(double totalScoreOfExams, int numOfExams){
    this.examScoreAvg = totalScoreOfExams/(double)numOfExams;
 }
 
 /*returns Average for exams*/
public double getAvgExamScore(){
   return examScoreAvg;
   }

   
/*calculates Average for labs*/
public void setAvgLabScore(double avgLabScore){
    this.labScoreAvg = avgLabScore;
 }
 
 /*returns Average for labs*/
public double getAvgLabScore(){
   return labScoreAvg;
   }

/*calculates Average for zyBooks*/
public void setAvgZybooksScore(double avgZybooks){
    this.zybooksScoreAvg = avgZybooks;
 }
 
 /*returns Average for Zybooks*/
public double getAvgZybooksScore(){
   return zybooksScoreAvg;
   }
               /*calculates Avg number grade */
public void avgNumberGrade(double projAvg,double examAvg, double zybooksAvg,double labAvg){
  this.avgNumGrade = (projAvg + examAvg + zybooksAvg + labAvg)/4;
  }
  
public double getAvgNumGrade(){
return this.avgNumGrade;
}

}