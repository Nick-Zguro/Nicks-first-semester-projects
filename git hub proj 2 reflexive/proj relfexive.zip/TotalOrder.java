
public class TotalOrder{ 

 private int[][] matrix;
   
   public TotalOrder(int[][] userMatrix) {            //sets pivate matrix equal to the main one
      this.matrix = userMatrix;
}


   public boolean antisymmetric() {                   //checks to see if their are ones diagnol from th e
      boolean antiSymmetric = true;
      for (int i = 0; i < matrix.length; ++i) {
        for(int j = 0; j< matrix.length;++j){
         if (matrix[i][j] == 1 && matrix[j][i] == 1 && j!=i){
          antiSymmetric = false;
          }
        }
     }
     return antiSymmetric;
  }
  

 public boolean reflexive() {
      for (int i = 0; i < matrix.length; ++i){       
         if (matrix[i][i] != 1) {
            return false;
         } 
      }
      return true;
   }


public boolean transitive() { 
      for (int x = 0; x < matrix.length; ++x){
         for (int y = 0; y < matrix.length; ++y){
            if (matrix[x][y] == 1) {
               for (int z = 0; z < matrix.length; ++z) {
                  if ((matrix[y][z] == 1) && (matrix[x][z] != 1)) {
                     return false;
                  }
               }
            }
         }
      }
      return true;
   }

 public boolean totalOrder() {
      if (transitive() && reflexive() && antisymmetric()) {
         return true;
      }
      return false;
   }
}