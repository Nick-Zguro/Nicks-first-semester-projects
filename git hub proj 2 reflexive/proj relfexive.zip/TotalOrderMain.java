import java.util.Scanner;
public class TotalOrderMain{
public static void main(String[] args) {
 int[][] myMatrix = {
                          {1,0,1,0,0,1},
                          {0,1,0,0,0,0},
                          {0,0,1,0,0,1},
                          {0,0,0,1,0,0},
                          {0,1,1,0,1,1},
                          {0,0,0,0,0,1}
                                       };
          
      TotalOrder testMatrix = new TotalOrder(myMatrix);    //create an object of a matrix
   
      System.out.println("Your matrix is...");
   
       if (testMatrix.antisymmetric()) {
         System.out.println("antisymmetric");            //Uses all methods to define the matrix
      }
      else {
         System.out.println("not antisymmetric");
      }
      
       if (testMatrix.reflexive()) {
         System.out.println("reflexive");
      }
      else {
         System.out.println("not reflexive");
      }
   

      if (testMatrix.transitive()) {
         System.out.println("transitive");
      }
      else {
         System.out.println("not transitive");
      }
   

      if (testMatrix.totalOrder()) {
         System.out.println("a total order");
      }
      else {
         System.out.println("not a total order");
      }
   }
}